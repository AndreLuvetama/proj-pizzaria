package com.pizzaria.prosper.Pizzaria.Prospere;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PizzariaProspereApplicationTests {

	@Test
	void contextLoads() {
	}

}
