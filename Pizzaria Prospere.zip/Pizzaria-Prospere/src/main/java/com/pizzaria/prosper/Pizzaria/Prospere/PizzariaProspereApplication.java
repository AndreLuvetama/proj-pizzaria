package com.pizzaria.prosper.Pizzaria.Prospere;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PizzariaProspereApplication {

	public static void main(String[] args) {
		SpringApplication.run(PizzariaProspereApplication.class, args);
	}

}
